
# 3I ATLAS STUDIO — Landing Page (GoDaddy Ready)

This package contains a single-page website for 3I ATLAS STUDIO.
Upload the contents of the folder to your hosting (GoDaddy) root.

## Files
- index.html — the landing page
- styles.css — the stylesheet
- assets/logo.svg — brand logo
- assets/favicon.svg — favicon

## GoDaddy quick steps
1. Log in → My Products → 3iatlas.studio → Manage.
2. If you have Web Hosting, open the File Manager (or cPanel) and go to the site root (often `/public_html`).
3. Upload **all files and the assets folder** keeping the same structure.
4. Ensure the entry file is named `index.html`.
5. Clear caches and visit: https://3iatlas.studio

## Customize
- Replace placeholder video URLs in the "Selected Work" section.
- Update social links in the Contact section.
- Colors can be changed in `styles.css` under `:root` variables.
